/**********************************************************************************
******************** COctopusCamera.cpp : implementation file
**********************************************************************************/

#include "stdafx.h"
#include "atmcd32d.h"
#include "Octopus.h"
#include "OctopusDoc.h"
#include "OctopusView.h"
#include "OctopusClock.h"
#include "OctopusCameraDlg.h"
#include "OctopusCameraDisplay.h"
#include "OctopusGrating.h"
#include "OctopusGlobals.h"
#include "OctopusLog.h"
#include "Octopus_LED.h"

#include <direct.h>
#include <stdlib.h>
#include <stdio.h>
#include <Mmsystem.h>

DWORD WINAPI FocusThread(LPVOID lpParameter);

extern COctopusGlobals    B;
extern COctopusLog*       glob_m_pLog;


//Initialization
Octopus_LED::Octopus_LED(CWnd* pParent)
	: CDialog(Octopus_LED::IDD, pParent)
	, LED_Intensity(0)
{    
	if( Create(Octopus_LED::IDD, pParent) ) 
		ShowWindow( SW_SHOW );

	ledIntensity = 0;
	led_slider.SetRange( 0, 100 );
	led_slider.SetPos( 100 );
	led_slider.SetTicFreq( 20 );
	laser_slider.SetRange( 0, 100 );
	laser_slider.SetPos( 100 );
	laser_slider.SetTicFreq( 20 );
	m_edit.SetDlgItemInt(LED_INTENSITY_VIEW, 0, false);
	
	Intensity = 0;
	LED_Intensity = 0;

	if ( glob_m_pLog != NULL ) 
		glob_m_pLog->Write(_T("Octopus_LED(CWnd* pParent) "));

	

}

void Octopus_LED::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange( pDX );
	ledIntensity = 0;
	laserIntensity = 0;
	DDX_Text( pDX, LED_INTENSITY_VIEW, ledIntensity);
	DDX_Control(pDX,	IDC_LED_INTENSITY_SLIDER,				led_slider);
	DDV_MinMaxInt(pDX, ledIntensity, 0, 100);
	DDX_Control(pDX, LED_INTENSITY_VIEW, m_edit);

	DDX_Text( pDX, LASER_INTENSITY_VIEW, laserIntensity);
	DDX_Control(pDX,	IDC_LASER_INTENSITY_SLIDER,				laser_slider);
	DDV_MinMaxInt(pDX, laserIntensity, 0, 100);
	DDX_Control(pDX, LASER_INTENSITY_VIEW, m_edit);
}  

BEGIN_MESSAGE_MAP(Octopus_LED, CDialog)

	ON_WM_TIMER()
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_LED_INTENSITY_SLIDER, OnNMCustomdrawLedIntensitySlider)
	ON_EN_KILLFOCUS(LED_INTENSITY_VIEW, &Octopus_LED::OnEnKillfocusIntensityView)
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_LASER_INTENSITY_SLIDER, &Octopus_LED::OnNMCustomdrawLedIntensitySlider2)
	ON_EN_KILLFOCUS(LASER_INTENSITY_VIEW, &Octopus_LED::OnEnKillfocusIntensityView2)
END_MESSAGE_MAP()

BOOL Octopus_LED::OnInitDialog() 
{
	CDialog::OnInitDialog();
	ECODE status = NULL;
	TRACE("Initializing Octopus_LED\n");
 
	hdrvr_9812 = NULL;
	hdass_9812_DAC = NULL;
    status = olDaInitialize(PTSTR("DT9812(00)"), &hdrvr_9812 );	
    if (status != OLNOERROR)
	{
	  TRACE("Error: %lu\n ",status);
      AfxMessageBox(_T("Connect to DT9812 board failed.\nHave you plugged it in and turned it on?"));
	}
	status = olDaGetDASS( hdrvr_9812, OLSS_DA, 0, &hdass_9812_DAC );
	status = olDaSetDataFlow( hdass_9812_DAC, OL_DF_SINGLEVALUE );
	status = olDaConfig( hdass_9812_DAC );
	if( status != OLNOERROR  ) 
	{
		TRACE("Error: %lu\n ",status);
		AfxMessageBox(_T("Error at Subsystem DAC"));
	}
	return TRUE;
}

Octopus_LED::~Octopus_LED() 
{
	SetLEDIntensity(0);
	SetLaserIntensity(0);
	olDaReleaseDASS( hdass_9812_DAC );
	olDaTerminate( hdrvr_9812 );
	TRACE("Ending Octopus_LED\n");
}

BOOL Octopus_LED::OnCommand(WPARAM wParam, LPARAM lParam) 
{
	int id = LOWORD(wParam);     // Notification code
	if( id == 2 ) return FALSE;  // Trap ESC key
	if( id == 1 ) return FALSE;  // Trap RTN key
    return CDialog::OnCommand(wParam, lParam);
}

/*********************************************************************************
* Start/stop continuous data aquisition
*********************************************************************************/


/*********************************************************************************
********************	Utility functions ****************************************
*********************************************************************************/
void Octopus_LED::LED_On(float intensity)
{
	TRACE("LED On called\n");
	SetLEDIntensity(intensity);
}
void Octopus_LED::LED_Off()
{
	SetLEDIntensity(0);
}
void Octopus_LED::SetLEDIntensity( float intensity )
{
	ECODE status = NULL;
	float volts = 0;

	volts = (intensity / 100) * 1024;
	volts = min(volts, 1024);
	volts = max(0, volts);
	//convert to DAC units
	status = olDaPutSingleValue( hdass_9812_DAC, volts, 0, 0 );
	CString str;
	str.Format(_T("LED Volts:%f\n"), volts);
	TRACE(str);
}

void Octopus_LED::SetLaserIntensity( float intensity )
{
	ECODE status = NULL;
	float volts = 0;

	volts = (intensity / 100) * 1024;
	volts = min(volts, 1024);
	volts = max(0, volts);
	//convert to DAC units//
	status = olDaPutSingleValue( hdass_9812_DAC, volts, 1, 0 );
	CString str;
	str.Format(_T("Laser Volts:%f\n"), volts);
	TRACE(str);
}
/************************************
 User interface etc
 ***********************************/


void Octopus_LED::OnNMCustomdrawLedIntensitySlider(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMCUSTOMDRAW pNMCD = reinterpret_cast<LPNMCUSTOMDRAW>(pNMHDR);
	
	int CurPos = led_slider.GetPos();
	CString str;
	Intensity = 100 - CurPos;
	ledIntensity = Intensity;
	SetLEDIntensity(Intensity);
	str.Format(_T("Intensity:%f\n"), Intensity);
	TRACE(str);
	LED_Intensity = Intensity;
	*pResult = 0;
}


void Octopus_LED::OnEnKillfocusIntensityView()
{
	// TODO: Add your control notification handler code here
	UpdateData(true);
	CString str;
	str.Format("From shutter: %d\n",ledIntensity);
	TRACE(str);
	led_slider.SetPos(100-ledIntensity);

}

void Octopus_LED::OnNMCustomdrawLedIntensitySlider2(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMCUSTOMDRAW pNMCD = reinterpret_cast<LPNMCUSTOMDRAW>(pNMHDR);
	// TODO: Add your control notification handler code here
	int CurPos = laser_slider.GetPos();
	laserIntensity = 100 - CurPos;
	SetLaserIntensity(100 - CurPos);
	CString str;
	str.Format(_T("Laser Intensity:%d\n"), 100 - CurPos);
	TRACE(str);
	*pResult = 0;
}

void Octopus_LED::OnEnKillfocusIntensityView2()
{
	UpdateData(true);
	CString str;
	str.Format("From shutter: %d\n",laserIntensity);
	TRACE(str);
	laser_slider.SetPos(100-laserIntensity);
	// TODO: Add your control notification handler code here
}
