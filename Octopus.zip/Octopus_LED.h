#if !defined(AFX_H_Octopus_LED)
#define AFX_H_Octopus_LED

#include "stdafx.h"
#include "OctopusGlobals.h"
#include "oldaapi.h"
#include "stdlib.h"
#include "afxwin.h"

class Octopus_LED : public CDialog
{

public:
	enum { IDD = IDC_LED };
	Octopus_LED(CWnd* pParent = NULL);
	virtual ~Octopus_LED();

protected:

	float Intensity;
	HDEV   hdrvr_9812;
	HDASS  hdass_9812_DAC;
	int ledIntensity;
	int laserIntensity;


	CSliderCtrl led_slider;
	CSliderCtrl laser_slider;
	virtual void DoDataExchange(CDataExchange* pDX);
	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);
	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	BOOL CALLBACK GetDriver( LPSTR lpszName, LPSTR lpszEntry, LPARAM lParam );
	void PrintIntensity();
	void SetLEDIntensity( float intensity );
	void SetLaserIntensity( float intensity );


public:
	void Octopus_LED::LED_On(float intensity);
	void Octopus_LED::LED_Off();
	afx_msg void OnNMCustomdrawLedIntensitySlider(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnStnClickedLedIntensity();
	int LED_Intensity;
	afx_msg void OnEnChangeIntensityView();
	afx_msg void OnBnClickedSubmitIntensity();
	afx_msg void OnEnKillfocusIntensityView();
	CEdit m_edit;
	afx_msg void OnNMCustomdrawLedIntensitySlider2(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnEnKillfocusIntensityView2();
};

#endif
