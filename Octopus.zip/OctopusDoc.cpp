///////////////////////////////////////////////////////////////////
// OctopusDoc.cpp : implementation of the COctopusDoc class
///////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Octopus.h"
#include "OctopusDoc.h"

IMPLEMENT_DYNCREATE(COctopusDoc, CDocument)

COctopusDoc::COctopusDoc()     {}
COctopusDoc::~COctopusDoc()    {}
BOOL COctopusDoc::OnNewDocument() {return TRUE;}


